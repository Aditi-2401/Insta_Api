package router

import (
	"go-server/middleware"

	"github.com/gorilla/mux"
)

// Router is exported and used in main.go
func Router() *mux.Router {

	router := mux.NewRouter()

	router.HandleFunc("/api/post", middleware.GetAllPosts).Methods("GET", "OPTIONS")
	router.HandleFunc("/api/post", middleware.CreatePost).Methods("POST", "OPTIONS")
	router.HandleFunc("/api/post/{id}", middleware.GetPost).Methods("GET", "OPTIONS")
	router.HandleFunc("/api/register", Register).Methods("POST", "OPTIONS")
	router.HandleFunc("/api/user/{id}", middleware.GetUser).Methods("GET", "OPTIONS")
	router.HandleFunc("/api/login", Login).Methods("POST", "OPTIONS")
	return router
}
