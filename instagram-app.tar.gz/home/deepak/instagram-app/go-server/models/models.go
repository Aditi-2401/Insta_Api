package models

import "go.mongodb.org/mongo-driver/bson/primitive"

type Post struct {
	ID     primitive.ObjectID `json:"_id,omitempty" bson:"_id,omitempty"`
	User    string            `json:"user,omitempty" bson:"user_id"`
	Image  string             `json:"image,omitempty" bson:"image"`
	Status bool               `json:"status,omitempty" bson:"status"`
	Created time.Time 		  `json:"created,omitempty" bson:"created_at"`
	Updated time.Time         `json:"updated,omitempty" bson:"updated_at"`
}

type User struct {
	ID     primitive.ObjectID      `json:"_id,omitempty" bson:"_id,omitempty"`
	FirstName   string             `json:"first_name,omitempty" bson:"first_name"`
	LastName   string              `json:"last_name,omitempty" bson:"last_name"`
	Phone   	string             `json:"phone,omitempty" bson:"phone"`
	Email       string             `json:"email,omitempty" bson:"email"`
	Status      bool               `json:"status,omitempty" bson:"status"`
	Created     time.Date 		   `json:"created,omitempty" bson:"created_at"`
	Updated     time.Time          `json:"updated,omitempty" bson:"updated_at"`
}
